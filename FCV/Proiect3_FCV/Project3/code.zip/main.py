import cv2
import numpy as np
import glob
import os

images = glob.glob("./0002_3.jpg")

print(images)
for image in images:
    image_name = image[2:8]
    print(image_name)

    os.makedirs("./" + image_name, exist_ok=True)

    img = cv2.imread(image)
    kernel = np.ones((5,5),np.uint8)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 120, 255, cv2.THRESH_BINARY_INV)

    # Dilating letters
    dilate_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 2))
    dilation = cv2.dilate(thresh, dilate_kernel, iterations = 7)
    cv2.imshow('dilation',dilation)

    # Finding contours
    contours,_ = cv2.findContours(dilation.copy(), cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    cnt = 0
    for c in contours:
            x,y,w,h = cv2.boundingRect(c)
            if h * w > 10000 :
                cnt += 1
                rect = cv2.minAreaRect(c)
                box = cv2.boxPoints(rect)
                box = np.int0(box)
                src = box.astype("float32")

                (tl, tr, br, bl) = box
                
                dst = np.array([
                        [0, 0],
                        [w - 1, 0],
                        [w - 1, h - 1],
                        [0, h - 1]], dtype = "float32")

                print(cnt, w, h)

                M = cv2.getPerspectiveTransform(src, dst)
                print(src)
                print(dst)
                cv2.imshow('img1',img)
                warped = cv2.warpPerspective(img.copy(), M, (w, h))
                cv2.imshow('img2',warped)
                cv2.waitKey(0)
                write_path = os.path.join("./"+image_name, image_name+ '_' + str(cnt) + '.jpg')
                cv2.imwrite(write_path, warped)

                # cv2.drawContours(img, [box], 0, (0, 0, 255), 2)


    # cv2.imshow('thresh',thresh)
    # cv2.imshow('dilation',dilation)
    cv2.imshow('img',img)


    cv2.waitKey(0)
    # cv2.destroyAllWindows()